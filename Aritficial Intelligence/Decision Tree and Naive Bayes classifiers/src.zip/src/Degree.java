
public enum Degree {
    LOW,MEDIUM,HIGH,VERY_HIGH
}